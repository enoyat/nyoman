
<?php $__env->startSection('content'); ?>
    <div class="container">
        <a href="<?php echo e(route('order')); ?>">
            <div id='soalBtn' class='btn btn-info btn-sm' title="Masukkan order"><span
                    class='glyphicon glyphicon-chevron-left'></span> Kembali</div>
        </a>
        <br>
        <br>
        <form action="<?php echo e(route('order.konfirmasi')); ?>" method="POST" role="form" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
        <table class="table " style="font-size: 11px">
            <?php
                $i = 1;
                $total = 0;
            ?>
            <?php $__currentLoopData = $dataorder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td width="20%">Kode Order</td>
                    <td>
                        <?php echo e($key->kdorder); ?>

                    </td>
                </tr>
                <tr>
                    <td>Total</td>
                    <td><?php echo e('Rp.' . number_format($key->total, 0, ',', '.')); ?>


                    </td>
                </tr>
                <tr>
                    <td>Status Pembayaran</td>
                    <td>


                        <?php if($key->status == '1'): ?>
                            <p style='color: blue'>Sudah Bayar</p>
                        <?php else: ?>
                            <p style='color: red'>Belum Bayar</p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>Bukti Pembayaran</td>
                    <td>
                      <input class="form-control" type="file" value="<?php echo e(old('filefoto')); ?>" name="filefoto"
                      id="filefoto">
                    </td>
                </tr>
                <tr>
                  <td></td>
                  <td>
                    <input type="hidden" name="kdorder" value="<?php echo e($key->kdorder); ?>">
                    <input type="hidden" name="total" value="<?php echo e($key->total); ?>">
                <button type="submit" class="btn btn-primary">Submit</button>
                  </td>
                </tr>
                    

                <?php $i++ ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\GitHub\nyoman\e-commerce\resources\views/detailbayar.blade.php ENDPATH**/ ?>