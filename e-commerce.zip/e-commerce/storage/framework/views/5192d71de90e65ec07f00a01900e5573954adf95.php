
<?php $__env->startSection('content'); ?>
<h3>Terima Kasih</h3>
<hr>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-success">
            <h4>Terima kasih telah berbelanja di toko kami.</h4>
            <p>
                Barang akan segera dikirim setelah pembayaran kami terima. 
                Silahkan upload bukti pembayaran Anda <a href="<?php echo e(URL::to('order')); ?>">disini</a>.
            </p>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\GitHub\nyoman\e-commerce\resources\views/sukses.blade.php ENDPATH**/ ?>