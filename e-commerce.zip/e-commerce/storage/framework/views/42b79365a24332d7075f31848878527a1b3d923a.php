
<?php $__env->startSection('content'); ?>
    <div id="myModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">                    
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </div>
    <h4>Pesanan Saya</h4>
    <hr>
    <table class="table " style="font-size: 11px">
        <thead>
            <tr>
                <th>
                    No Order
                </th>
                <th>
                    Tgl. Order
                </th>
                <th style="text-align: left;">
                    Total
                </th>
                <th>
                    Produk
                </th>

                <th>Pengiriman</th>
                <th>Konfirmasi Pembayaran</th>
                <th>
                    Status Pembayaran
                </th>
                <th>
                    Status Order
                </th>
                <th>
                    No. Resi
                </th>
            </tr>
        </thead>
        <tbody>

            <?php $i = 1;
            $total = 0; ?>
            <?php $__currentLoopData = $dataorder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($key->kdorder); ?>

                    </td>
                    <td>
                        <?php echo e(date('d-m-Y', strtotime($key->tglorder))); ?>

                    </td>
                    <td style="text-align: right;"><?php echo e('Rp.' . number_format($key->total, 0, ',', '.')); ?>


                    </td>

                    <td>
                        <div class="img-responsive" id="viewgambar"><img src="<?php echo e(asset('assets/inventory/' . $key->foto)); ?>"
                                height="80px"><br>
                            <?php echo $key->namabarang; ?> <br>
                            <a class="btn btn-xs btn-info" href="<?php echo e(URL::to('order/resi/' . $key->kdorder)); ?>"><span
                                    class='glyphicon glyphicon-upload'> </span> Detail Order</a>
                        </div>
                    </td>

                    <td>
                        Penerima: <b><?php echo $key->penerima; ?> </b><br>
                        Alamat Penerima: <b><?php echo $key->alamatpenerima; ?> </b> <br>
                        Jasa Kurir: <b><?php echo $key->kurir; ?> </b>



                    </td>
                    <td>
                        <?php if($key->filebukti != null): ?>
                            <a href="<?php echo e(asset('assets/inventory/' . $key->filebukti)); ?>"
                                target="_blank"><?php echo e($key->filebukti); ?></a><br>
                        <?php else: ?>
                            <a class="btn btn-xs btn-warning"
                                href="<?php echo e(URL::to('order/detailbayar/' . $key->kdorder)); ?>"><span
                                    class='glyphicon glyphicon-book'> </span> Konfirmasi Pembayaran</a>
                        <?php endif; ?>
                    </td>
                    <td>


                        <?php
                        
                        if ($key->f_status == '1') {
                            echo "<p style='color: blue'>Sudah dibayar</p>";
                        } elseif ($key->f_status == '0') {
                            echo "<p style='color: red'>Belum Bayar</p>";
                        }
                        ?>

                    </td>
                    <td>


                        <?php
                        
                        if ($key->f_proses == '0') {
                            echo "<p style='color: blue'>Belum diproses</p>";
                        } elseif ($key->f_proses == '1') {
                            echo "<p style='color: red'>Dikemas</p>";
                        } elseif ($key->f_proses == '2') {
                            echo "<p style='color: red'>Dikirimkan</p>";
                        }
                        ?>
                    </td>
                    <td>
                        Tgl.Kirim: <?php echo e($key->tglkirim); ?> <h5>Resi: <?php echo e($key->noresi); ?></h5>
                        <?php if ($key->f_proses=="0") { ?>
                        <a class="btn btn-xs btn-danger" data-toggle="modal"
                            data-target="#modal_hapus<?php echo $key->kdorder; ?>"><span class='glyphicon glyphicon-trash'> </span>
                            BATALKAN PESANAN</a><br>
                        <?php } ?>
                        <?php if($key->f_proses == '2'): ?>
                            <div data-url="<?php echo e(route('order.terimaorder', $key->kdorder)); ?>"
                                class="btn btn-primary btn-sm btn-action" style="font-size: 10px;">Terima Pesanan
                            </div>
                        <?php endif; ?>

                    </td>

                </tr>


                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
        </form>
    </table>

    </div>

    <?php
foreach($dataorder as $i):
    $kdorder=$i->kdorder;
?>
    <!-- ============ MODAL HAPUS  =============== -->
    <div class="modal fade" id="modal_hapus<?php echo $kdorder; ?>" tabindex="-1" role="dialog" aria-labelledby="largeModal"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    <h3 class="modal-title" id="myModalLabel">No. Order <?php echo $kdorder; ?></h3>
                </div>
                <form class="form-horizontal" method="post" action="<?php echo e(route('checkout.batal')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-bodyx">
                        Batalkan Pesanan <?php echo $kdorder; ?> ?
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="kdorder" value="<?php echo $kdorder; ?>">
                        <button class="btn btn-danger">Hapus</button>
                        <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>

                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach;?>

    <script>
        $('.btn-action').click(function() {

            var url = $(this).data("url");
            $.ajax({
                url: url,
                dataType: 'html',
                success: function(res) {

                    // get the ajax response data
                    var data = res;

                    // update modal content here
                    // you may want to format data or
                    // update other modal elements here too
                    $('.modal-body').html(data);

                    // show modal
                    $('#myModal').modal('show');

                },
                error: function(request, status, error) {
                    console.log("ajax call went wrong:" + request.responseText);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\GitHub\nyoman\e-commerce\resources\views/order.blade.php ENDPATH**/ ?>