
<?php $__env->startSection('content'); ?>   

<?php 
foreach ($databarang as $key ) 
{ 
	$kdbarang 	=$key->kdbarang;
	$namabarang	=$key->namabarang;
	$deskripsi	= $key->deskripsi;
	$hargabeli 	= $key->hargabeli;
	$hargajual 	= $key->hargajual;
	$berat 	= $key->berat;
	$fotolama = $key->foto;
	$kdkategori= $key->kdkategori;
	$namakategori= $key->namakategori;

}
?>

<div class="row">
<div class="col-md-12 col-lg-6">
	<div class="panel panel-info">
		<div class="panel-heading">
			<h3 class="panel-title">Form bakpia</h3>
		</div>
		<div class="panel-body">	
				    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
        
     <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Ada kesalahan data, silahkan dicek kembali<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>			
	<form action="<?php echo e(route('abarang.update')); ?>" method="POST" role="form"  enctype="multipart/form-data">
		<?php echo csrf_field(); ?>					
				<div class="form-group">
					<label >Kode makanan</label>
					<input type="text" class="form-control" id="kdbarang" name="kdbarang" placeholder="kode barang" value="<?php echo $kdbarang; ?>" required="">
				</div>
				<div class="form-group">
					<label >Nama makanan</label>
					<input type="text" class="form-control" id="namabarang" name="namabarang" placeholder="Nama barang" value="<?php echo $namabarang; ?>" required="">
				</div>			
				<div class="form-group">
					<label >deskripsi</label>
					<textarea name="deskripsi" required="" class="form-control" rows="10"><?php echo $deskripsi; ?></textarea>
				</div>
				<div class="form-group">
					<label >Harga Beli</label>
					<input type="text" class="form-control" id="hargabeli" name="hargabeli" placeholder="Harga" value="<?php echo $hargabeli; ?>" required="">
				</div>			
				<div class="form-group">
					<label >Harga Jual</label>
					<input type="text" class="form-control" id="hargajual" name="hargajual" placeholder="Harga" value="<?php echo $hargajual; ?>" required="">
				</div>
				<div class="form-group">
					<label >Berat (gram)</label>
					<input type="text" class="form-control" id="berat" name="berat" placeholder="Berat" value="<?php echo $berat; ?>" required="">
				</div>
				<div class="form-group">
						<label for="">Kategori</label>
					<select name="kdkategori" id="kdkategori" class="form-control" required="required">
					<option value="<?php echo $kdkategori; ?>"><?php echo $namakategori; ?></option>
					<?php 
					foreach ($kategori as $ktg ) 
					{ ?>
						<option value="<?php echo $ktg->kdkategori;?>"><?php echo $ktg->namakategori;?></option>
					<?php				
					}
					?>
					</select>		
				</div>				
				<div class="form-group">									
					<label>Foto Utama</label>
					<input type="file" name="filefoto">
					<input type="hidden" name="fotolama" value="<?php echo $fotolama; ?>" placeholder="">
					<img src="<?php echo e(asset('assets/inventory/'.$fotolama)); ?>" class="img-responsive" >
				</div>
  				<button type="submit" class="btn btn-primary">Update</button>
				<a href="<?php echo e(route('abarang')); ?>"><div class="btn btn-primary">Kembali</div></a>

			</form>		
			<br>
				<div class="form-group">									
					<label>Foto Gallery Barang</label><br>
					<?php $__currentLoopData = $key->get_foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					            
					<div class="img-thumbnail img-responsive" style="width: 75px; text-align: center" >
						<img src="<?php echo e(asset('assets/inventory/'.$key2->foto)); ?>" class="img-responsive" >
					            <a href="<?php echo e(route('abarang.hapusgallery',$key2->kdfoto)); ?>">Hapus</a>
					        </div>
					       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</div>

				<form action="<?php echo e(route('abarang.uploadgallery')); ?>" method="POST" role="form"  enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
				<br>
				<input type="hidden" class="form-control" id="kdbarang" name="kdbarang" placeholder="kode barang" value="<?php echo $kdbarang; ?>" required="">
				<div class="form-group">									
					<label>Upload Foto Gallery</label>
					<input type="file" name="filefoto">
					<button type="submit" class="btn btn-primary">Upload</button>
				</div>
  				

				</form>
			</div>
		</div>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\GitHub\nyoman\e-commerce\resources\views/admin/barang/formeditbarang.blade.php ENDPATH**/ ?>